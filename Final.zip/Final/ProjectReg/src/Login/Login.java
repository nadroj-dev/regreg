package Login;

import javax.swing.*;

import Admin.adminRegForm;
import Loaner.loanerRegForm;
import Merchant.merchantRegForm;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Login extends JFrame {

	private JComboBox<String> userTypeComboBox;
	private JTextField usernameField;
	private JPasswordField passwordField;

	private static final String JDBC_URL = "jdbc:mysql://localhost:3306/java_registration";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "";

	public Login() {
		setTitle("Login Form");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(494, 385);
		setLocationRelativeTo(null);
		getContentPane().setLayout(new BorderLayout());

		JPanel loginPanel = new JPanel();
		loginPanel.setLayout(null);

		JLabel userTypeLabel = new JLabel("User Type:");
		userTypeLabel.setFont(new Font("Dialog", Font.PLAIN, 15));
		userTypeLabel.setBounds(73, 204, 74, 27);
		loginPanel.add(userTypeLabel);

		userTypeComboBox = new JComboBox<>(new String[]{"Admin", "Loaner", "Merchant"});
		userTypeComboBox.setFont(new Font("Dialog", Font.PLAIN, 15));
		userTypeComboBox.setBounds(153, 199, 95, 37);
		loginPanel.add(userTypeComboBox);

		JLabel usernameLabel = new JLabel("Username:");
		usernameLabel.setFont(new Font("Dialog", Font.PLAIN, 15));
		usernameLabel.setBounds(73, 85, 74, 37);
		loginPanel.add(usernameLabel);

		usernameField = new JTextField();
		usernameField.setFont(new Font("Dialog", Font.PLAIN, 15));
		usernameField.setBounds(153, 86, 194, 39);
		loginPanel.add(usernameField);

		JLabel passwordLabel = new JLabel("Password:");
		passwordLabel.setFont(new Font("Dialog", Font.PLAIN, 15));
		passwordLabel.setBounds(73, 152, 74, 27);
		loginPanel.add(passwordLabel);

		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Dialog", Font.PLAIN, 15));
		passwordField.setBounds(153, 148, 194, 39);
		loginPanel.add(passwordField);

		JButton loginButton = new JButton("LOGIN");
		loginButton.setFont(new Font("Dialog", Font.BOLD, 15));
		loginButton.setBounds(167, 262, 164, 37);
		loginButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String userType = (String) userTypeComboBox.getSelectedItem();
				String username = usernameField.getText();
				String password = new String(passwordField.getPassword());

				if (verifyLogin(userType, username, password)) {
					JOptionPane.showMessageDialog(Login.this, "Login Successful");

					switch (userType) {
					case "Admin":
						openAdminPage();
						break;
					case "Loaner":
						// Open Loaner Page here
						break;
					case "Merchant":
						// Open Merchant Page here
						break;
					}
					dispose();
				} else {
					JOptionPane.showMessageDialog(Login.this, "Invalid username or password");
				}
			}
		});
		loginPanel.add(loginButton);

		JLabel lblAdminSignup = new JLabel("Admin Signup");
		lblAdminSignup.setFont(new Font("Dialog", Font.BOLD, 15));
		lblAdminSignup.setForeground(Color.BLUE);
		lblAdminSignup.setBounds(20, 310, 150, 30);
		lblAdminSignup.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblAdminSignup.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// Open Admin Registration Form here
				openAdminRegForm();
			}
		});
		loginPanel.add(lblAdminSignup);

		JLabel lblLoanerSignup = new JLabel("Loaner Signup");
		lblLoanerSignup.setFont(new Font("Dialog", Font.BOLD, 15));
		lblLoanerSignup.setForeground(Color.BLUE);
		lblLoanerSignup.setBounds(180, 310, 150, 30);
		lblLoanerSignup.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblLoanerSignup.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// Open Loaner Registration Form here
				openLoanerRegForm();
			}
		});
		loginPanel.add(lblLoanerSignup);

		JLabel lblMerchantSignup = new JLabel("Merchant Signup");
		lblMerchantSignup.setFont(new Font("Dialog", Font.BOLD, 15));
		lblMerchantSignup.setForeground(Color.BLUE);
		lblMerchantSignup.setBounds(340, 310, 150, 30);
		lblMerchantSignup.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblMerchantSignup.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// Open Merchant Registration Form here
				openMerchantRegForm();
			}
		});
		loginPanel.add(lblMerchantSignup);

		getContentPane().add(loginPanel, BorderLayout.CENTER);

		JLabel lblNewLabel = new JLabel("LOGIN");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel.setBounds(207, 26, 67, 37);
		loginPanel.add(lblNewLabel);
	}

	private boolean verifyLogin(String userType, String username, String password) {
		String tableName = "";
		switch (userType) {
		case "Admin":
			tableName = "admins";
			break;
		case "Loaner":
			tableName = "loaner";
			break;
		case "Merchant":
			tableName = "merchant";
			break;
		}
		String query = "SELECT * FROM " + tableName + " WHERE username=? AND password=?";
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD);
				PreparedStatement stmt = conn.prepareStatement(query)) {
			stmt.setString(1, username);
			stmt.setString(2, password);
			ResultSet rs = stmt.executeQuery();
			return rs.next();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	private void openAdminPage() {
		// Open Admin Page here
		adminPage adminPage = new adminPage();
		adminPage.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Update this line
		adminPage.setVisible(true);
	}

	private void openAdminRegForm() {
	    // Open Admin Registration Form here
	    adminRegForm adminRegForm = new adminRegForm();
	    adminRegForm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Update this line
	    adminRegForm.setVisible(true);
	}

	private void openLoanerRegForm() {
	    // Open Loaner Registration Form here
	    loanerRegForm loanerRegForm = new loanerRegForm();
	    loanerRegForm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Update this line
	    loanerRegForm.setVisible(true);
	}

	private void openMerchantRegForm() {
	    // Open Merchant Registration Form here
	    merchantRegForm merchantRegForm = new merchantRegForm();
	    merchantRegForm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Update this line
	    merchantRegForm.setVisible(true);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new Login().setVisible(true);
			}
		});
	}
}
