package Login;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class adminPage extends JFrame {

    public adminPage() {
        setTitle("Admin Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 325);
        setLocationRelativeTo(null); 
        getContentPane().setLayout(new BorderLayout());

        JPanel adminPanel = new JPanel();
        adminPanel.setLayout(null);

        JLabel titleLabel = new JLabel("Admin Page");
        titleLabel.setFont(new Font("Dialog", Font.BOLD, 20));
        titleLabel.setBounds(240, 10, 120, 30);
        adminPanel.add(titleLabel);

        JButton viewLoanerButton = new JButton("View Loaner Details");
        viewLoanerButton.setFont(new Font("Dialog", Font.PLAIN, 15));
        viewLoanerButton.setBounds(200, 70, 200, 30);
        adminPanel.add(viewLoanerButton);

        JButton addUserButton = new JButton("Add User");
        addUserButton.setFont(new Font("Dialog", Font.PLAIN, 15));
        addUserButton.setBounds(200, 120, 200, 30);
        adminPanel.add(addUserButton);

        JButton editUserButton = new JButton("Edit User");
        editUserButton.setFont(new Font("Dialog", Font.PLAIN, 15));
        editUserButton.setBounds(200, 170, 200, 30);
        adminPanel.add(editUserButton);

        JButton deleteUserButton = new JButton("Delete User");
        deleteUserButton.setFont(new Font("Dialog", Font.PLAIN, 15));
        deleteUserButton.setBounds(200, 220, 200, 30);
        adminPanel.add(deleteUserButton);

        viewLoanerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Placeholder for viewing loaner details
                JOptionPane.showMessageDialog(adminPage.this, "View Loaner Details");
            }
        });

        addUserButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Placeholder for adding a user
                JOptionPane.showMessageDialog(adminPage.this, "Add User");
            }
        });

        editUserButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Placeholder for editing a user
                JOptionPane.showMessageDialog(adminPage.this, "Edit User");
            }
        });

        deleteUserButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Placeholder for deleting a user
                JOptionPane.showMessageDialog(adminPage.this, "Delete User");
            }
        });

        getContentPane().add(adminPanel, BorderLayout.CENTER);
    }
}
